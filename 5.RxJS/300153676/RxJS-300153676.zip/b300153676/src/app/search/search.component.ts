import { ChangeDetectorRef, Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { ApicallService } from '../shared/apicall.service';
import { Country } from '../shared/country';

@Component({
  standalone: false,
  selector: 'Search',
  templateUrl: './search.component.html',
})
export class SearchComponent implements OnDestroy {
  name = '';
  countries: Country[] = [];
  message = '';
  private request?: Subscription;

  constructor(private api: ApicallService, private changes: ChangeDetectorRef) {}

  searchCapital(): void {
    this.request?.unsubscribe();
    this.countries = [];
    this.message = '';
    if (!this.name.trim()) {
      this.message = 'Saisis une capitale.';
      return;
    }
    this.request = this.api.searchCountryByName(this.name).subscribe({
      next: countries => {
        this.countries = countries;
        this.message = countries.length ? '' : 'Aucun pays trouvé.';
        console.log(countries);
        this.changes.markForCheck();
      },
      error: error => {
        this.message = error.status === 404 ? 'Aucun pays trouvé.' : 'La recherche a échoué.';
        this.changes.markForCheck();
      }
    });
  }

  ngOnDestroy(): void {
    this.request?.unsubscribe();
  }
}
