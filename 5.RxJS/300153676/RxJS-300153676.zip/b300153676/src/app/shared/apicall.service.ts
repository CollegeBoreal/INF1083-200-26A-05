import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Country } from './country';

interface CountryResponse {
  name: { common: string };
  capital?: string[];
}

@Injectable({ providedIn: 'root' })
export class ApicallService {
  constructor(private http: HttpClient) {}

  searchCountryByName(capital: string): Observable<Country[]> {
    const query = encodeURIComponent(capital.trim());
    return this.http.get<CountryResponse[]>('https://countries.nexperts.nl/capital/' + query).pipe(
      map(rows => rows.map((row, id) => ({
        id,
        name: row.name.common,
        capital: (row.capital ?? []).join(', ')
      })))
    );
  }
}
