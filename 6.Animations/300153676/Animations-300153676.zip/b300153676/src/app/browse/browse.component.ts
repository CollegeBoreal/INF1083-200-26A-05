import { Component, OnInit } from '@angular/core'
import { RadSideDrawer } from 'nativescript-ui-sidedrawer'
import { Application, View } from '@nativescript/core'

@Component({
  standalone: false,
  selector: 'Browse',
  templateUrl: './browse.component.html',
})
export class BrowseComponent implements OnInit {
  constructor() {
    // Use the component constructor to inject providers.
  }

  ngOnInit(): void {
    // Init your component properties here.
  }

  onDrawerButtonTap(): void {
    const sideDrawer = <RadSideDrawer>Application.getRootView()
    sideDrawer.showDrawer()
  }

  running = false;

  async animate(view: View): Promise<void> {
    if (this.running) return;
    this.running = true;
    const duration = 300;
    try {
      await view.animate({ opacity: 0, duration });
      await view.animate({ opacity: 1, duration });
      await view.animate({ translate: { x: 200, y: 200 }, duration });
      await view.animate({ translate: { x: 0, y: 0 }, duration });
      await view.animate({ scale: { x: 5, y: 5 }, duration });
      await view.animate({ scale: { x: 1, y: 1 }, duration });
      await view.animate({ rotate: 180, duration });
      await view.animate({ rotate: 0, duration });
      console.log('Animation finished');
    } catch (error) {
      console.log(String(error));
    } finally {
      this.running = false;
    }
  }
}
