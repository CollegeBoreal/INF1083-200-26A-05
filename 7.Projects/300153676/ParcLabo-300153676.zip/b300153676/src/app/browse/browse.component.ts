import { Component, inject } from '@angular/core';
import { File, ImageSource } from '@nativescript/core';
import { isAvailable, requestCameraPermissions, takePicture } from '@nativescript/camera';
import { InventoryService } from '../shared/inventory.service';

@Component({ standalone: false, selector: 'Browse', templateUrl: './browse.component.html' })
export class BrowseComponent {
  private readonly inventory = inject(InventoryService);
  name = '';
  location = '';
  available = true;
  message = '';
  preview?: ImageSource;
  busy = false;

  async photograph(): Promise<void> {
    if (this.busy) return;
    this.busy = true;
    try {
      if (!isAvailable()) {
        this.message = 'Aucun appareil photo disponible.';
        return;
      }
      if (!(await requestCameraPermissions()).Success) {
        this.message = 'Autorise la caméra dans les réglages pour prendre une photo.';
        return;
      }
      const asset = await takePicture({ width: 900, height: 900, keepAspectRatio: true, saveToGallery: false });
      if (asset) this.preview = await ImageSource.fromAsset(asset);
      this.message = '';
    } catch {
      this.message = 'Aucune nouvelle photo. Tu peux réessayer.';
    } finally {
      this.busy = false;
    }
  }

  async save(): Promise<void> {
    if (this.busy) return;
    const name = this.name.trim();
    const location = this.location.trim();
    if (!name || !location) {
      this.message = 'Remplis le nom et la salle.';
      return;
    }
    this.busy = true;
    let photo: string | undefined;
    try {
      if (this.preview) {
        photo = 'materiel-' + Date.now() + '-' + Math.random().toString(36).slice(2) + '.jpg';
        if (!(await this.preview.saveToFileAsync(this.inventory.photoPath(photo), 'jpg', 85))) {
          throw new Error('Photo non enregistrée');
        }
      }
      await this.inventory.add({ name, location, available: this.available, photo });
      this.message = name + ' ajouté à l’inventaire.';
      this.name = this.location = '';
      this.available = true;
      this.preview = undefined;
    } catch {
      this.message = 'Enregistrement impossible. Réessaie.';
      if (photo && File.exists(this.inventory.photoPath(photo))) await File.fromPath(this.inventory.photoPath(photo)).remove();
    } finally {
      this.busy = false;
    }
  }
}
