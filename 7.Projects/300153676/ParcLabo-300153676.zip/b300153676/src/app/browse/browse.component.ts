import { Component, inject } from '@angular/core';
import { InventoryService } from '../shared/inventory.service';

@Component({
  standalone: false,
  selector: 'Browse',
  templateUrl: './browse.component.html',
})
export class BrowseComponent {
  private readonly inventory = inject(InventoryService);
  name = '';
  location = '';
  available = true;
  message = '';

  save(): void {
    const name = this.name.trim();
    const location = this.location.trim();
    if (!name || !location) {
      this.message = 'Remplis le nom et la salle.';
      return;
    }
    try {
      this.inventory.add(name, location, this.available);
      this.message = name + ' ajouté.';
      this.name = this.location = '';
      this.available = true;
    } catch {
      this.message = 'Enregistrement impossible. Réessaie.';
    }
  }
}
