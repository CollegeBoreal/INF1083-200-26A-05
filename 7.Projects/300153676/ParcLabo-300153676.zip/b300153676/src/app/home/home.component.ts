import { Component, inject } from '@angular/core';
import { InventoryService } from '../shared/inventory.service';

@Component({
  standalone: false,
  selector: 'Home',
  templateUrl: './home.component.html',
})
export class HomeComponent {
  readonly inventory = inject(InventoryService);
}
