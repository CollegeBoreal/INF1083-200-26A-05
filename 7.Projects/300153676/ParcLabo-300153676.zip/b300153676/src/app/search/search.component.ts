import { Component, inject } from '@angular/core';
import { InventoryService } from '../shared/inventory.service';

@Component({
  standalone: false,
  selector: 'Search',
  templateUrl: './search.component.html',
})
export class SearchComponent {
  readonly inventory = inject(InventoryService);
}
