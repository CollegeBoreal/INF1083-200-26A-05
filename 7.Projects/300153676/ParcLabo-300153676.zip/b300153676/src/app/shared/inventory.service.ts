import { computed, Injectable, signal } from '@angular/core';
import { ApplicationSettings, knownFolders, path } from '@nativescript/core';
import { openOrCreate } from '@nativescript-community/sqlite';

export interface Device {
  name: string;
  location: string;
  available: boolean;
  photo?: string;
}

const insertDevice = 'INSERT INTO devices(name, location, available, photo) VALUES (?, ?, ?, ?)';
const legacyKey = 'parclabo.inventory.v1';

@Injectable({ providedIn: 'root' })
export class InventoryService {
  private readonly entries = signal<Device[]>([]);
  readonly devices = this.entries.asReadonly();
  readonly available = computed(() => this.devices().filter(d => d.available).length);
  readonly error = signal('');
  private db: ReturnType<typeof openOrCreate>;
  private ready = this.initialize().catch(() => {
    this.error.set('Impossible d’ouvrir l’inventaire. Ferme puis rouvre ParcLabo.');
  });

  private async initialize(): Promise<void> {
    this.db = openOrCreate('parclabo.db');
    await this.db.execute('CREATE TABLE IF NOT EXISTS devices (id INTEGER PRIMARY KEY, name TEXT NOT NULL, location TEXT NOT NULL, available INTEGER NOT NULL, photo TEXT)');
    const saved = ApplicationSettings.getString(legacyKey);
    if (saved) {
      await this.db.transaction(async (_cancel, tx) => {
        await tx.execute('CREATE TABLE IF NOT EXISTS migrations (name TEXT PRIMARY KEY)');
        if (await tx.get('SELECT name FROM migrations WHERE name = ?', [legacyKey])) return;
        for (const device of JSON.parse(saved) as Device[]) {
          await tx.execute(insertDevice, [device.name, device.location, Number(device.available), null]);
        }
        await tx.execute('INSERT INTO migrations VALUES (?)', [legacyKey]);
      });
      ApplicationSettings.remove(legacyKey);
    }
    const rows = await this.db.select('SELECT name, location, available, photo FROM devices ORDER BY id DESC');
    this.entries.set(rows.map(row => ({ name: row.name, location: row.location,
      available: Boolean(row.available), photo: row.photo })));
  }

  photoPath(filename: string): string {
    return path.join(knownFolders.documents().getFolder('materiel').path, filename);
  }

  async add(device: Device): Promise<void> {
    await this.ready;
    if (this.error()) throw new Error(this.error());
    await this.db.execute(insertDevice, [device.name, device.location, Number(device.available), device.photo || null]);
    this.entries.update(devices => [device, ...devices]);
  }
}
