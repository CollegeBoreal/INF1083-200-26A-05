import { computed, Injectable, signal } from '@angular/core';
import { ApplicationSettings } from '@nativescript/core';

export interface Device {
  name: string;
  location: string;
  available: boolean;
}

@Injectable({ providedIn: 'root' })
export class InventoryService {
  private readonly key = 'parclabo.inventory.v1';
  private readonly entries = signal<Device[]>(this.load());
  readonly devices = this.entries.asReadonly();
  readonly available = computed(() => this.devices().filter(d => d.available).length);

  add(name: string, location: string, available: boolean): void {
    const devices = [...this.devices(), { name, location, available }];
    ApplicationSettings.setString(this.key, JSON.stringify(devices));
    this.entries.set(devices);
  }

  private load(): Device[] {
    const saved = ApplicationSettings.getString(this.key);
    return saved ? JSON.parse(saved) : [];
  }
}
